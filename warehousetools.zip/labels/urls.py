from django.conf.urls import url
from . import views # from the current folder import views.py

app_name = 'labels'
urlpatterns = [

    url(r'^$', views.index, name='index'),
    url(r'^(?P<barcode>.*)/(?P<pallet_number>[0-9]+)/(?P<sku>.*)/(?P<supplier>.*)/html/$',
        views.label, name='label'),
    url(r'^(?P<barcode>.*)/(?P<pallet_number>.*)/(?P<sku>.*)/(?P<supplier>.*)/table/$',
        views.label_table, name='label_table'),

]