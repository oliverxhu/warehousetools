from django.apps import AppConfig


class LabelsConfig(AppConfig):
    name = 'labels'
